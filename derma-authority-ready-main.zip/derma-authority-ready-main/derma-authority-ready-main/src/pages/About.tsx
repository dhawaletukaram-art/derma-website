import { Link } from "react-router-dom";
import doctor from "@/assets/doctor.jpg";
import { ArrowRight } from "lucide-react";

const About = () => (
  <div>
    <section className="bg-gradient-hero py-20">
      <div className="container mx-auto text-center max-w-3xl">
        <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">About Us</span>
        <h1 className="font-serif text-5xl md:text-6xl mt-3">About La Aesthetique</h1>
        <p className="mt-6 text-muted-foreground text-lg">A modern Skin, Hair & Laser Clinic dedicated to delivering effective, ethical, and personalized dermatology care.</p>
      </div>
    </section>

    <section className="container mx-auto py-20 grid lg:grid-cols-2 gap-12 items-center">
      <img src={doctor} alt="Dr. Pradnya Asutkar" loading="lazy" width={800} height={1024} className="rounded-3xl shadow-soft object-cover w-full" />
      <div>
        <h2 className="font-serif text-4xl mb-6">Our Story</h2>
        <p className="text-muted-foreground leading-relaxed mb-4">
          La Aesthetique was founded with a vision to deliver advanced dermatology and aesthetic solutions in a comfortable, professional, and patient-focused environment.
        </p>
        <p className="text-muted-foreground leading-relaxed">
          We believe that healthy skin and hair are essential for confidence and overall well-being. Our goal is to offer treatments that are effective, ethical, and tailored to each patient's unique concerns.
        </p>
      </div>
    </section>

    <section className="bg-muted/40 py-20">
      <div className="container mx-auto grid md:grid-cols-2 gap-10">
        <div className="bg-background p-10 rounded-2xl shadow-card">
          <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">Mission</span>
          <h3 className="font-serif text-3xl mt-3 mb-4">Our Mission</h3>
          <p className="text-muted-foreground leading-relaxed">
            To provide world-class dermatology and aesthetic treatments using modern technology, personalized care, and ethical practice — helping patients feel confident in their skin and hair.
          </p>
        </div>
        <div className="bg-background p-10 rounded-2xl shadow-card">
          <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">Values</span>
          <h3 className="font-serif text-3xl mt-3 mb-4">Our Values</h3>
          <ul className="space-y-2 text-muted-foreground">
            {["Patient-Centered Care","Ethical Treatment Approach","Hygiene & Safety Standards","Transparency & Trust","Advanced Technology","Continuous Learning & Innovation"].map(v => (
              <li key={v} className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-magenta" /> {v}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>

    <section className="container mx-auto py-20">
      <div className="text-center mb-12">
        <h2 className="font-serif text-4xl">Our Clinic Facilities</h2>
        <p className="text-muted-foreground mt-3">Modern dermatology and laser technology for safe, effective treatments.</p>
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        {["Advanced Laser Equipment","Modern Consultation Rooms","Skin Analysis Technology","Hygienic Procedure Rooms","Comfortable Patient Waiting Area","Personalized Consultation Support"].map(f => (
          <div key={f} className="p-6 rounded-2xl border border-border bg-muted/30">
            <div className="font-serif text-xl">{f}</div>
          </div>
        ))}
      </div>
    </section>

    <section className="container mx-auto pb-20">
      <div className="bg-gradient-primary rounded-3xl p-12 text-center text-primary-foreground">
        <h2 className="font-serif text-4xl mb-4">Begin Your Transformation</h2>
        <Link to="/appointment" className="inline-flex items-center gap-2 px-8 py-4 bg-white text-primary font-semibold rounded-full">
          Book Consultation <ArrowRight size={18} />
        </Link>
      </div>
    </section>
  </div>
);

export default About;
