import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { services } from "@/data/clinic";

const Services = () => (
  <div>
    <section className="bg-gradient-hero py-20">
      <div className="container mx-auto text-center max-w-3xl">
        <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">Services</span>
        <h1 className="font-serif text-5xl md:text-6xl mt-3">Comprehensive Skin, Hair & Laser Treatments</h1>
        <p className="mt-6 text-muted-foreground text-lg">Advanced Aesthetic & Dermatology Solutions Tailored for You</p>
      </div>
    </section>

    <section className="container mx-auto py-20 space-y-10">
      {services.map((s, i) => {
        const Icon = s.icon;
        return (
          <div key={s.slug} className={`grid lg:grid-cols-2 gap-10 items-center ${i%2===1 ? "lg:[direction:rtl]" : ""}`}>
            <div className="lg:[direction:ltr]">
              <div className="w-14 h-14 rounded-2xl bg-gradient-primary flex items-center justify-center mb-5">
                <Icon size={26} className="text-primary-foreground" />
              </div>
              <h2 className="font-serif text-4xl mb-4">{s.title}</h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">{s.short}</p>
              <Link to={`/services/${s.slug}`} className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-semibold rounded-full hover:opacity-90 transition">
                {s.cta} <ArrowRight size={16} />
              </Link>
            </div>
            <div className="lg:[direction:ltr] grid sm:grid-cols-2 gap-3">
              {s.treatments.slice(0, 6).map(t => (
                <div key={t.name} className="p-4 rounded-xl bg-muted/40 border border-border">
                  <div className="font-medium text-sm">{t.name}</div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </section>
  </div>
);

export default Services;
