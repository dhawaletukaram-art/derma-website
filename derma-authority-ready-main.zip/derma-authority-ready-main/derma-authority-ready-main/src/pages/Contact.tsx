import { Link } from "react-router-dom";
import { Phone, Mail, MapPin, Clock, MessageCircle, ArrowRight } from "lucide-react";

const Contact = () => (
  <div>
    <section className="bg-gradient-hero py-20">
      <div className="container mx-auto text-center max-w-3xl">
        <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">Contact</span>
        <h1 className="font-serif text-5xl md:text-6xl mt-3">Contact La Aesthetique</h1>
        <p className="mt-6 text-muted-foreground text-lg">We're Here to Help You Begin Your Skin & Hair Transformation Journey</p>
      </div>
    </section>

    <section className="container mx-auto py-20 grid lg:grid-cols-3 gap-6">
      {[
        { icon: Phone, title: "Phone", v: "8459323304", href: "tel:8459323304" },
        { icon: Mail, title: "Email", v: "info@laaesthetique.com", href: "mailto:info@laaesthetique.com" },
        { icon: MapPin, title: "Location", v: "Nagpur, Maharashtra" },
        { icon: Clock, title: "Mon - Sat", v: "10:00 AM – 8:00 PM" },
        { icon: Clock, title: "Sunday", v: "Closed" },
        { icon: MessageCircle, title: "WhatsApp", v: "+91 8459323304", href: "https://wa.me/918459323304" },
      ].map(c => {
        const Icon = c.icon;
        const Comp: any = c.href ? "a" : "div";
        return (
          <Comp key={c.title} href={c.href} className="p-7 rounded-2xl border border-border bg-background hover:shadow-card transition flex items-start gap-4">
            <div className="w-11 h-11 rounded-xl bg-magenta-light flex items-center justify-center shrink-0">
              <Icon size={20} className="text-magenta" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">{c.title}</div>
              <div className="font-medium mt-1">{c.v}</div>
            </div>
          </Comp>
        );
      })}
    </section>

    <section className="container mx-auto pb-20">
      <div className="bg-muted/40 rounded-3xl p-10 md:p-14 grid lg:grid-cols-2 gap-10">
        <div>
          <h2 className="font-serif text-4xl mb-3">Find Us Easily</h2>
          <p className="text-muted-foreground mb-6">Visit our clinic for a personalized consultation in a comfortable, modern environment.</p>
          <div className="aspect-video rounded-2xl overflow-hidden bg-background border border-border">
            <iframe
              title="La Aesthetique Location"
              src="https://www.google.com/maps?q=Nagpur+Maharashtra&output=embed"
              width="100%" height="100%" loading="lazy" referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
        <div className="bg-background rounded-2xl p-8 shadow-card">
          <h3 className="font-serif text-3xl mb-2">Need Quick Assistance?</h3>
          <p className="text-muted-foreground mb-6">Connect with us directly on WhatsApp for appointment booking, treatment inquiries, and consultation support.</p>
          <a href="https://wa.me/918459323304" className="inline-flex items-center gap-2 px-7 py-3.5 bg-magenta text-white font-semibold rounded-full hover:opacity-90 transition">
            <MessageCircle size={18} /> Chat on WhatsApp
          </a>
          <div className="mt-8 pt-8 border-t border-border">
            <h4 className="font-serif text-2xl mb-3">Book an Appointment</h4>
            <p className="text-sm text-muted-foreground mb-4">Use our online booking page to choose a time that works for you.</p>
            <Link to="/appointment" className="inline-flex items-center gap-2 px-7 py-3.5 bg-gradient-primary text-primary-foreground font-semibold rounded-full">
              Schedule Consultation <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </div>
    </section>
  </div>
);

export default Contact;
