import { useParams, Link, Navigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { services } from "@/data/clinic";

const ServiceDetail = () => {
  const { slug } = useParams();
  const service = services.find(s => s.slug === slug);
  if (!service) return <Navigate to="/services" replace />;
  const Icon = service.icon;

  return (
    <div>
      <section className="bg-gradient-hero py-20">
        <div className="container mx-auto max-w-4xl">
          <Link to="/services" className="text-sm text-muted-foreground hover:text-primary">← All Services</Link>
          <div className="flex items-center gap-4 mt-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-primary flex items-center justify-center">
              <Icon size={26} className="text-primary-foreground" />
            </div>
            <h1 className="font-serif text-5xl md:text-6xl">{service.title}</h1>
          </div>
          <p className="mt-6 text-muted-foreground text-lg max-w-2xl">{service.intro}</p>
          <p className="mt-3 text-muted-foreground max-w-2xl">{service.short}</p>
        </div>
      </section>

      <section className="container mx-auto py-20">
        <h2 className="font-serif text-3xl mb-10 text-center">Treatments We Offer</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {service.treatments.map(t => (
            <div key={t.name} className="p-7 rounded-2xl border border-border bg-background shadow-card hover:shadow-soft transition">
              <h3 className="font-serif text-xl mb-2">{t.name}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{t.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container mx-auto pb-20">
        <div className="bg-gradient-primary rounded-3xl p-12 text-center text-primary-foreground">
          <h2 className="font-serif text-3xl md:text-4xl mb-4">Need Personalized Treatment Guidance?</h2>
          <p className="mb-8 max-w-2xl mx-auto text-white/85">Book a consultation with Dr. Pradnya Asutkar to understand the most suitable treatment options.</p>
          <Link to="/appointment" className="inline-flex items-center gap-2 px-8 py-4 bg-white text-primary font-semibold rounded-full">
            Book Consultation <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default ServiceDetail;
