const categories = [
  { title: "Acne Treatment Results", color: "bg-teal-light" },
  { title: "Pigmentation Correction", color: "bg-magenta-light" },
  { title: "Hair Regrowth", color: "bg-beige" },
  { title: "Laser Hair Reduction", color: "bg-teal-light" },
  { title: "Anti-Ageing Transformations", color: "bg-magenta-light" },
  { title: "Skin Rejuvenation", color: "bg-beige" },
];

const Gallery = () => (
  <div>
    <section className="bg-gradient-hero py-20">
      <div className="container mx-auto text-center max-w-3xl">
        <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">Gallery</span>
        <h1 className="font-serif text-5xl md:text-6xl mt-3">Real Transformations</h1>
        <p className="mt-6 text-muted-foreground text-lg">
          Witness visible improvements through our advanced dermatology and aesthetic treatments — natural, confidence-boosting results.
        </p>
      </div>
    </section>

    <section className="container mx-auto py-20">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map(c => (
          <div key={c.title} className={`${c.color} rounded-3xl p-8 aspect-[4/5] flex flex-col justify-end`}>
            <div className="bg-background/80 backdrop-blur rounded-2xl p-5">
              <div className="font-serif text-xl">{c.title}</div>
              <div className="text-xs text-muted-foreground mt-1">Before & After</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  </div>
);

export default Gallery;
