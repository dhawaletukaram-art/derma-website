import { Link } from "react-router-dom";
import { ArrowRight, Phone, MessageCircle, CheckCircle2, Star } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { services, whyChoose, processSteps, testimonials, faqs } from "@/data/clinic";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const Home = () => (
  <div>
    {/* Hero */}
    <section className="bg-gradient-hero relative overflow-hidden">
      <div className="container mx-auto grid lg:grid-cols-2 gap-12 items-center py-16 lg:py-24">
        <div className="animate-fade-up">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/70 backdrop-blur border border-primary/10 text-xs font-medium text-primary mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-magenta" />
            Skin · Hair · Laser Clinic in Nagpur
          </div>
          <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl font-semibold leading-[1.05] text-foreground">
            Transform Your <span className="text-gradient-primary">Skin, Hair</span> & Confidence
          </h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-xl leading-relaxed">
            Advanced Skin, Hair & Laser Treatments by Dr. Pradnya Asutkar — personalized care using modern technology and medically proven procedures.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/appointment" className="inline-flex items-center gap-2 px-7 py-3.5 bg-gradient-primary text-primary-foreground font-semibold rounded-full hover:opacity-90 transition shadow-soft">
              Book Appointment <ArrowRight size={18} />
            </Link>
            <a href="tel:8459323304" className="inline-flex items-center gap-2 px-7 py-3.5 bg-white text-foreground font-semibold rounded-full border border-border hover:border-primary transition">
              <Phone size={16} /> Call Now
            </a>
            <a href="https://wa.me/918459323304" className="inline-flex items-center gap-2 px-7 py-3.5 bg-magenta text-white font-semibold rounded-full hover:opacity-90 transition">
              <MessageCircle size={16} /> WhatsApp
            </a>
          </div>
          <div className="mt-10 grid grid-cols-2 sm:grid-cols-3 gap-3 max-w-xl">
            {["Advanced Laser Tech","Personalized Solutions","Expert Dermatology","Modern Treatments","Hygienic & Safe"].map(f => (
              <div key={f} className="flex items-center gap-2 text-sm text-foreground/80">
                <CheckCircle2 size={16} className="text-primary shrink-0" /> {f}
              </div>
            ))}
          </div>
        </div>
        <div className="relative animate-fade-in">
          <div className="absolute -inset-4 bg-gradient-magenta opacity-20 blur-3xl rounded-full" />
          <img src={hero} alt="Modern dermatology clinic" width={1280} height={1280} className="relative rounded-3xl shadow-soft object-cover w-full aspect-square" />
        </div>
      </div>
    </section>

    {/* Trust strip */}
    <section className="border-y border-border bg-muted/40">
      <div className="container mx-auto py-10 grid md:grid-cols-4 gap-6 text-center">
        {[
          { k: "MBBS, MD", v: "Skin & VD" },
          { k: "Fellowship", v: "Lasers" },
          { k: "Fellowship", v: "Cosmetology & Aesthetic Medicine" },
          { k: "Trusted by", v: "1000+ Patients in Nagpur" },
        ].map(c => (
          <div key={c.v}>
            <div className="font-serif text-2xl text-primary">{c.k}</div>
            <div className="text-sm text-muted-foreground">{c.v}</div>
          </div>
        ))}
      </div>
    </section>

    {/* About preview */}
    <section className="container mx-auto py-20">
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">About</span>
          <h2 className="font-serif text-4xl md:text-5xl mt-3 mb-6">About La Aesthetique</h2>
          <p className="text-muted-foreground leading-relaxed mb-4">
            La Aesthetique is a modern Skin, Hair & Laser Clinic dedicated to providing comprehensive dermatology and aesthetic solutions — diagnosis and treatment for chronic and infectious skin disorders, hair loss, laser procedures, pigmentation, anti-ageing, and cosmetic dermatology.
          </p>
          <p className="text-muted-foreground leading-relaxed mb-6">
            We focus on customized treatment plans based on each patient's skin type, concerns, and goals. Our commitment to safety, hygiene, transparency, and patient satisfaction makes us one of the trusted aesthetic clinics in Nagpur.
          </p>
          <Link to="/about" className="inline-flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all">
            Read More About Us <ArrowRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {["Acne Treatment Results","Pigmentation Correction","Hair Regrowth","Skin Rejuvenation"].map((c,i) => (
            <div key={c} className={`rounded-2xl p-6 ${i%2===0 ? "bg-teal-light" : "bg-magenta-light"} ${i===1 ? "mt-8" : ""}`}>
              <div className="font-serif text-xl text-foreground">{c}</div>
              <div className="text-xs text-muted-foreground mt-2">Real patient transformations</div>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* Services */}
    <section id="services" className="bg-muted/40 py-20">
      <div className="container mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">Services</span>
          <h2 className="font-serif text-4xl md:text-5xl mt-3">Our Specialized Treatments</h2>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map(s => {
            const Icon = s.icon;
            return (
              <Link key={s.slug} to={`/services/${s.slug}`} className="group bg-background rounded-2xl p-7 shadow-card hover:shadow-soft transition border border-border/50 hover:border-primary/30">
                <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center mb-5">
                  <Icon size={22} className="text-primary-foreground" />
                </div>
                <h3 className="font-serif text-2xl mb-3">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-5">{s.short}</p>
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-primary group-hover:gap-3 transition-all">
                  {s.cta} <ArrowRight size={14} />
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </section>

    {/* Why Choose Us */}
    <section className="container mx-auto py-20">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">Why Choose Us</span>
        <h2 className="font-serif text-4xl md:text-5xl mt-3">Why Patients Choose La Aesthetique</h2>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {whyChoose.map(w => {
          const Icon = w.icon;
          return (
            <div key={w.title} className="p-7 rounded-2xl border border-border bg-background hover:bg-muted/40 transition">
              <Icon size={28} className="text-magenta mb-4" />
              <h3 className="font-serif text-xl mb-2">{w.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{w.desc}</p>
            </div>
          );
        })}
      </div>
    </section>

    {/* Process */}
    <section className="bg-teal-deep text-white py-20">
      <div className="container mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">Process</span>
          <h2 className="font-serif text-4xl md:text-5xl mt-3">Our Treatment Process</h2>
        </div>
        <div className="grid md:grid-cols-5 gap-6">
          {processSteps.map(p => (
            <div key={p.step} className="text-center">
              <div className="font-serif text-5xl text-magenta mb-3">{p.step}</div>
              <h3 className="font-serif text-xl mb-2">{p.title}</h3>
              <p className="text-sm text-white/70 leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* Testimonials */}
    <section className="container mx-auto py-20">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">Testimonials</span>
        <h2 className="font-serif text-4xl md:text-5xl mt-3">What Our Patients Say</h2>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {testimonials.map(t => (
          <div key={t.name} className="p-7 rounded-2xl bg-muted/40 border border-border">
            <div className="flex gap-0.5 mb-3 text-magenta">
              {Array(5).fill(0).map((_,i) => <Star key={i} size={14} fill="currentColor" />)}
            </div>
            <p className="text-sm text-foreground/80 leading-relaxed mb-4 italic">"{t.text}"</p>
            <div className="font-serif text-lg">{t.name}</div>
            <div className="text-xs text-muted-foreground">{t.role}</div>
          </div>
        ))}
      </div>
    </section>

    {/* FAQ */}
    <section className="bg-muted/40 py-20">
      <div className="container mx-auto max-w-3xl">
        <div className="text-center mb-12">
          <span className="text-xs uppercase tracking-[0.25em] text-magenta font-semibold">FAQs</span>
          <h2 className="font-serif text-4xl md:text-5xl mt-3">Frequently Asked Questions</h2>
        </div>
        <Accordion type="single" collapsible className="space-y-3">
          {faqs.map((f,i) => (
            <AccordionItem key={i} value={`f-${i}`} className="bg-background rounded-xl border border-border px-5">
              <AccordionTrigger className="text-left font-medium">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>

    {/* CTA */}
    <section className="container mx-auto py-20">
      <div className="bg-gradient-primary rounded-3xl p-12 md:p-16 text-center text-primary-foreground relative overflow-hidden">
        <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-magenta/30 blur-3xl" />
        <h2 className="font-serif text-4xl md:text-5xl mb-4 relative">Book Your Consultation Today</h2>
        <p className="max-w-2xl mx-auto mb-8 text-white/85 relative">
          Your journey to healthy skin and beautiful confidence starts here. Experience advanced dermatology and aesthetic care.
        </p>
        <Link to="/appointment" className="relative inline-flex items-center gap-2 px-8 py-4 bg-white text-primary font-semibold rounded-full hover:bg-white/90 transition">
          Book Appointment <ArrowRight size={18} />
        </Link>
      </div>
    </section>
  </div>
);

export default Home;
