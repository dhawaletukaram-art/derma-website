import { Sparkles, Scissors, Zap, Flower2, Activity, Droplet, ShieldCheck, Stethoscope } from "lucide-react";

export type Treatment = { name: string; desc?: string };
export type Service = {
  slug: string;
  title: string;
  short: string;
  intro: string;
  icon: any;
  treatments: Treatment[];
  cta: string;
};

export const services: Service[] = [
  {
    slug: "skin",
    title: "Skin Treatments",
    short: "Comprehensive treatments for acne, pigmentation, scars, infections, allergies, skin rejuvenation, and chronic skin disorders using modern dermatology techniques.",
    intro: "Personalised dermatology solutions for every skin type and concern.",
    icon: Sparkles,
    cta: "Explore Skin Treatments",
    treatments: [
      { name: "Acne Scar Treatment", desc: "Targeted procedures to reduce acne scars and improve skin texture." },
      { name: "Chemical Peels", desc: "Exfoliating treatments to brighten skin tone and texture." },
      { name: "Pigmentation Reduction", desc: "Treatments for melasma, dark spots, and uneven skin tone." },
      { name: "Hydra Facial", desc: "Deep cleansing and hydration for glowing, refreshed skin." },
      { name: "Wart & Skin Tag Removal", desc: "Safe, in-clinic removal of warts and skin tags." },
      { name: "Cryotherapy", desc: "Freezing therapy for warts, skin tags, and select lesions." },
      { name: "Dermoscopy & Onychoscopy", desc: "Advanced diagnostics for skin and nail examination." },
      { name: "Intralesional Injections", desc: "Precision treatment for specific skin conditions." },
      { name: "Microdermabrasion", desc: "Gentle exfoliation for smoother, fresher-looking skin." },
    ],
  },
  {
    slug: "hair",
    title: "Hair Treatments",
    short: "Advanced hair restoration and scalp treatments for hair fall, thinning hair, baldness, dandruff, and scalp health improvement.",
    intro: "Modern restoration therapies for healthier, fuller hair.",
    icon: Scissors,
    cta: "Explore Hair Treatments",
    treatments: [
      { name: "PRP Therapy", desc: "Platelet-rich plasma to stimulate natural hair growth." },
      { name: "GFC Mesotherapy", desc: "Growth factor concentrate therapy for hair density." },
      { name: "Stem Cell Therapy", desc: "Advanced regenerative treatment for hair restoration." },
      { name: "Hair Threads", desc: "Thread-based stimulation for follicle health." },
      { name: "Derma Roller", desc: "Microneedling for scalp stimulation and hair growth." },
      { name: "Derma Pen", desc: "Precision microneedling for hair regrowth therapy." },
      { name: "Trichoscopy", desc: "Digital scalp and hair analysis for accurate diagnosis." },
      { name: "Laser Cap Therapy", desc: "Low-level laser therapy for hair density." },
    ],
  },
  {
    slug: "laser",
    title: "Laser Treatments",
    short: "State-of-the-art laser procedures for skin rejuvenation, permanent hair reduction, tattoo removal, pigmentation correction, and scar treatments.",
    intro: "Precision laser technology for visible, lasting results.",
    icon: Zap,
    cta: "Explore Laser Treatments",
    treatments: [
      { name: "Permanent Hair Removal", desc: "Long-lasting laser hair reduction for all body areas." },
      { name: "Tattoo Removal", desc: "Safe laser removal of unwanted tattoos." },
      { name: "Laser Facial", desc: "Brightening laser facial for radiant skin." },
      { name: "Pigmentation Removal", desc: "Targeted laser treatment for pigmentation and dark spots." },
      { name: "Scar Reduction", desc: "Laser procedures to minimise scars and irregularities." },
      { name: "Stretch Marks Reduction", desc: "Advanced treatments to reduce stretch marks." },
      { name: "Skin Rejuvenation", desc: "Laser therapy for youthful, radiant skin." },
    ],
  },
  {
    slug: "anti-ageing",
    title: "Anti-Ageing Treatments",
    short: "Advanced anti-ageing procedures to restore youthful skin, improve elasticity, reduce wrinkles, and enhance facial contours.",
    intro: "Restore youthful, healthy-looking skin with modern anti-ageing procedures.",
    icon: Flower2,
    cta: "Explore Anti-Ageing Treatments",
    treatments: [
      { name: "Botox", desc: "Reduces fine lines and wrinkles for a smoother appearance." },
      { name: "Dermal Fillers", desc: "Restores volume and enhances facial contours." },
      { name: "Skin Boosters", desc: "Hydrating injectables for radiant, plump skin." },
      { name: "Skin Glow Therapy", desc: "Treatments for luminous, glowing complexion." },
      { name: "Thread Lift Treatments", desc: "Non-surgical lifting and tightening using threads." },
    ],
  },
  {
  slug: "clinical-dermatology",
  title: "Clinical Dermatology",
  short: "Comprehensive diagnosis and treatment for skin, hair, and nail conditions using advanced dermatological care.",
  intro: "Expert clinical dermatology treatments for healthier skin, hair, and nails.",
  icon: Stethoscope,
  cta: "Explore Clinical Dermatology",
  treatments: [
    { name: "Acne Treatment", desc: "Personalized treatments to control acne and prevent scarring." },
    { name: "Eczema Management", desc: "Relief and long-term care for dry, itchy, inflamed skin." },
    { name: "Psoriasis Treatment", desc: "Advanced therapies to reduce scaling, redness, and discomfort." },
    { name: "Fungal Infection Treatment", desc: "Effective solutions for skin, scalp, and nail fungal infections." },
    { name: "Pigmentation Disorders", desc: "Treatments for melasma, dark spots, and uneven skin tone." },
    { name: "Hair & Scalp Disorders", desc: "Diagnosis and treatment for hair fall, dandruff, and scalp conditions." },
  ],
},
{
  slug: "bridal-packages",
  title: "Bridal Packages",
  short: "Luxury bridal skincare and beauty treatments designed to achieve flawless, radiant skin for your special day.",
  intro: "Get wedding-ready with personalized bridal skincare and aesthetic treatments.",
  icon: Sparkles,
  cta: "Explore Bridal Packages",
  treatments: [
    { name: "Bridal Skin Glow Therapy", desc: "Customized facials and treatments for radiant, glowing skin." },
    { name: "Pre-Bridal Acne & Pigmentation Care", desc: "Targeted solutions for clear, even-toned skin before the wedding." },
    { name: "HydraFacial for Brides", desc: "Deep cleansing and hydration treatment for instant freshness and glow." },
    { name: "Laser Hair Reduction", desc: "Smooth, hair-free skin with advanced laser treatments." },
    { name: "Skin Brightening Peels", desc: "Gentle peels to improve skin texture and enhance brightness." },
    { name: "Post-Bridal Skin Rejuvenation", desc: "Restorative treatments to maintain healthy, youthful skin after the wedding." },
  ],
},
];

export const whyChoose = [
  { icon: Stethoscope, title: "Experienced Dermatologist", desc: "Treatments led by qualified skin and aesthetic specialist Dr. Pradnya Asutkar." },
  { icon: Zap, title: "Modern Technology", desc: "Advanced laser and dermatology equipment for precise, effective procedures." },
  { icon: Sparkles, title: "Personalized Care", desc: "Customized treatment plans designed for your skin and hair concerns." },
  { icon: ShieldCheck, title: "Hygienic Environment", desc: "Safe, sanitized, and patient-friendly clinical setup." },
  { icon: Activity, title: "Result-Oriented", desc: "Evidence-based procedures focused on visible, long-lasting results." },
  { icon: Droplet, title: "Transparent Consultation", desc: "Honest recommendations and clear treatment guidance." },
];

export const processSteps = [
  { step: "01", title: "Consultation", desc: "Detailed skin/hair analysis and understanding patient concerns." },
  { step: "02", title: "Diagnosis", desc: "Scientific assessment using dermatology tools and examination." },
  { step: "03", title: "Personalized Plan", desc: "Customized procedures and skincare recommendations." },
  { step: "04", title: "Treatment", desc: "Safe and effective treatment execution." },
  { step: "05", title: "Follow-Up", desc: "Continuous monitoring and aftercare guidance." },
];

export const testimonials = [
  { name: "Priya S.", role: "Acne Treatment", text: "My acne completely cleared after a few sessions. Dr. Pradnya is very knowledgeable and caring." },
  { name: "Anjali M.", role: "PRP Therapy", text: "Hair fall has reduced significantly. The clinic is hygienic and the staff is wonderful." },
  { name: "Rohit K.", role: "Laser Hair Removal", text: "Painless sessions with great results. Highly recommend La Aesthetique." },
  { name: "Neha P.", role: "Anti-Ageing", text: "My skin looks naturally younger. The treatment plan was perfectly tailored to me." },
  { name: "Ashwini Dhonge", role: "Anti-Ageing", text: "Within 15 days, I had a very good experience with this medicine. It reduced my symptoms and cured almost 75% of my fungal infection. I am feeling much better now." },
   { name: "Sameer Moon", role: "Anti-Ageing", text: "I HAVE CONSULTED TO DR PRADYA MAM FOR MY FATHER IN LAW, HE WAS SUFFERING FROM LONG TIME PSORIASIS AND WAS ADMITTED TO HOSPITAL UNDER THE GUIDANCE OF DR PRADYA MAM, WE ARE VERY HAPPY TO SHARE THAT WE ARE VERY HAPPY WITH HER CONUSLTATION AND RECOVERED WITHIN A WEEK SINCE THE TREATMENT STARTED." },
];

export const faqs = [
  { q: "Are the treatments safe?", a: "Yes, all treatments are performed by qualified medical professionals using FDA-approved technology and proven techniques." },
  { q: "How long do results last?", a: "Results vary by treatment and individual. Many treatments offer long-lasting effects with proper aftercare and maintenance sessions." },
  { q: "How many sessions will I need?", a: "The number of sessions depends on your skin condition, treatment type, and desired results." },
  { q: "Is there downtime after treatment?", a: "Most treatments involve minimal downtime, though some procedures may require short recovery periods." },
  { q: "Do you provide treatments for both men and women?", a: "Yes, we provide skin, hair, and aesthetic treatments for both men and women." },
];
