import { Link } from "react-router-dom";
import { Phone, Mail, MapPin, Instagram, MessageCircle } from "lucide-react";

const Footer = () => (
  <footer className="bg-teal-deep text-white/90 mt-20">
    <div className="container mx-auto py-16 grid md:grid-cols-4 gap-10">
      <div>
        <div className="flex items-center gap-2 mb-4">
          <div className="w-10 h-10 rounded-full bg-gradient-magenta flex items-center justify-center">
            <span className="font-serif font-bold text-lg">L</span>
          </div>
          <span className="font-serif text-xl font-semibold">La Aesthetique</span>
        </div>
        <p className="text-sm text-white/70 leading-relaxed">
          Modern Skin, Hair & Laser Clinic in Nagpur led by Dr. Pradnya Asutkar.
        </p>
      </div>

      <div>
        <h4 className="font-serif text-lg mb-4">Quick Links</h4>
        <ul className="space-y-2 text-sm text-white/70">
          {["Home","About Us","Services","Doctor Profile","Testimonials","FAQs","Contact Us"].map(l => (
            <li key={l}><Link to="/" className="hover:text-white">{l}</Link></li>
          ))}
        </ul>
      </div>

      <div>
        <h4 className="font-serif text-lg mb-4">Treatments</h4>
        <ul className="space-y-2 text-sm text-white/70">
          {["Acne Treatment","Hair Fall Treatment","PRP Therapy","Laser Hair Removal","Pigmentation","Anti-Ageing"].map(t => (
            <li key={t}><Link to="/services" className="hover:text-white">{t}</Link></li>
          ))}
        </ul>
      </div>

      <div>
        <h4 className="font-serif text-lg mb-4">Contact</h4>
        <ul className="space-y-3 text-sm text-white/70">
          <li className="flex items-start gap-2"><Phone size={16} className="mt-0.5"/> 8459323304</li>
          <li className="flex items-start gap-2"><Mail size={16} className="mt-0.5"/> info@laaesthetique.com</li>
          <li className="flex items-start gap-2"><MapPin size={16} className="mt-0.5"/> Nagpur, Maharashtra</li>
          <li className="flex items-center gap-3 pt-2">
            <a href="#" className="hover:text-white"><Instagram size={18}/></a>
            <a href="https://wa.me/918459323304" className="hover:text-white"><MessageCircle size={18}/></a>
          </li>
        </ul>
      </div>
    </div>
    <div className="border-t border-white/10 py-5 text-center text-xs text-white/50">
      © {new Date().getFullYear()} La Aesthetique. All rights reserved.
    </div>
  </footer>
);

export default Footer;
